<!DOCTYPE>
<html>
	<head
		<title>Inserting Product</title>
	</head>

<body bgcolor="skyblue">
	
	
	
		<form function="insert_product.php" method="post" enctype="multipart/form-data">
			
			<table align="center" width="1000px" border="2" bgcolor="lightgreen">
				
				<tr>
					<td colspan=""><h2>Insert New Post Here</h2></td>
				</tr>
				
				<tr>
					<td colspan=""><h2>Product Title</h2></td>
					<td><input type="text" name="product_title"</td>
				</tr>
				
		
		</form>
		
			